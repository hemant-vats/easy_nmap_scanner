import nmap
import os
import datetime as dt
 ## Making and changing directory to save scans
folder = os.path.join(os.getcwd(),'scans',str(dt.datetime.today().date()),str(dt.datetime.today().time()))
banner = '''
███████╗ █████╗ ███████╗██╗   ██╗    ███╗   ██╗███╗   ███╗ █████╗ ██████╗     ███████╗ ██████╗ █████╗ ███╗   ██╗███╗   ██╗███████╗██████╗ 
██╔════╝██╔══██╗██╔════╝╚██╗ ██╔╝    ████╗  ██║████╗ ████║██╔══██╗██╔══██╗    ██╔════╝██╔════╝██╔══██╗████╗  ██║████╗  ██║██╔════╝██╔══██╗
█████╗  ███████║███████╗ ╚████╔╝     ██╔██╗ ██║██╔████╔██║███████║██████╔╝    ███████╗██║     ███████║██╔██╗ ██║██╔██╗ ██║█████╗  ██████╔╝
██╔══╝  ██╔══██║╚════██║  ╚██╔╝      ██║╚██╗██║██║╚██╔╝██║██╔══██║██╔═══╝     ╚════██║██║     ██╔══██║██║╚██╗██║██║╚██╗██║██╔══╝  ██╔══██╗
███████╗██║  ██║███████║   ██║       ██║ ╚████║██║ ╚═╝ ██║██║  ██║██║         ███████║╚██████╗██║  ██║██║ ╚████║██║ ╚████║███████╗██║  ██║
╚══════╝╚═╝  ╚═╝╚══════╝   ╚═╝       ╚═╝  ╚═══╝╚═╝     ╚═╝╚═╝  ╚═╝╚═╝         ╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝
--Created By Hemant Vats
'''

print(banner)
try:
    os.chdir(folder)
except:
    os.makedirs(folder)
    os.chdir(folder)

print('Scans will be saved in: ',os.getcwd())
#################################################

class ping_sweep():
    arg = '-sn'
    def ping_sweep(): ## code to check all online hosts ##
        print('Please enter gateway ip address or list of gateway ip addreses: ',end='')
        ip = list(map(str,input().split(',')))
        ns = nmap.PortScanner()
        for j in ip:
            ns.scan(hosts = j+'/24', arguments='-sn -oN ping_sweep')
            print('all hosts up for '+ j + '/24 are:')
            for i in ns.all_hosts():
                if ns[i].state()=='up':
                    print(i)
class no_host_discovery():
    arg = '-Pn'
    def no_host_discovery(): ## code to check all online hosts silently##
        print('Please enter gateway ip address or list of gateway ip addreses: ',end='')
        ip = list(map(str,input().split(',')))
        ns = nmap.PortScanner()
        for j in ip:
            ns.scan(hosts = j+'/24', arguments='-Pn -oN no_host_discovery')
            print('all hosts up for '+ j + '/24 are:')
            for i in ns.all_hosts():
                if ns[i].state()=='up':
                    print(i)

class full_scan_noised():
    arg = '-sSVC -O -A'
    def full_scan_noised(): ## code for full scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        ns.scan(ip, ports, '-sSVC -O -A -oN full_scan')
        print(ns.scanstats())
        print(ns.csv())

class syn_scan():
    arg = '-sS'
    def syn_scan(): ## code for full scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        ns.scan(ip, ports, '-sS -oN syn_scan')
        print(ns.scanstats())
        print(ns.csv())

class service_version_detection():
    arg = '-sV'
    def service_version_detection(): ## code for full scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        ns.scan(ip, ports, '-sV -oN service_version_detection')
        print(ns.scanstats())
        print(ns.csv())

class default_nse_scripts():
    arg = '-sC'
    def default_nse_scripts(): ## code for full scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        ns.scan(ip, ports, '-sC -oN default_nse_scripts')
        print(ns.scanstats())
        print(ns.csv())

class tcp_connect():
    arg = '-sT'
    def tcp_connect(): ## code for tcp service scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        ns.scan(ip, ports, '-sT -oN tcp_scan')
        print(ns.scanstats())
        print(ns.csv())

class udp_connect():
    arg = '-sU'
    def udp_connect(): ## code for UDP service scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        ns.scan(ip, ports, '-sU -oN udp_scan')
        print(ns.scanstats())
        print(ns.csv())

class check_firewall():
    arg = '-sA'
    def check_firewall(): ## code for UDP service scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ports = input('please enter port range: ')
        ns = nmap.PortScanner()
        ns.scan(hosts=ip,ports = ports,arguments='-sA --reason -oN firewall_status')
        print(ns.scanstats())
        print(ns.csv())

class fin_scan():
    arg = '-sF'
    def fin_scan(): ## code for UDP service scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ports = input('please enter port range: ')
        ns = nmap.PortScanner()
        ns.scan(hosts=ip,ports = ports,arguments='-sF --reason -oN fin_scan')
        print(ns.scanstats())
        print(ns.csv())

class null_scan():
    arg = '-sN'
    def null_scan(): ## code for UDP service scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ports = input('please enter port range: ')
        ns = nmap.PortScanner()
        ns.scan(hosts=ip,ports = ports,arguments='-sN --reason -oN null_scan')
        print(ns.scanstats())
        print(ns.csv())

class xmas_scan():
    arg = '-sX'
    def xmas_scan(): ## code for UDP service scan ##
        print('Please enter host ip address: ', end='')
        ip = input()
        ports = input('please enter port range: ')
        ns = nmap.PortScanner()
        ns.scan(hosts=ip,ports = ports,arguments='-sX --reason -oN xmas_scan')
        print(ns.scanstats())
        print(ns.csv())

class decoy():
    def __init__(self,decoy_ip):
        self.decoy_ip = decoy_ip
        if int(decoy_ip):
            decoy_ip = 'RND:'+decoy_ip
        else:
            decoy_ip = decoy_ip

    def decoy():
        c = False
        while c == False:
            try:
                ip = input("please enter the host IP address: ")
                choose = int(input('press 1 to enter decoy IPs or press 2 for random IPs: '))
            except:
                print('please enter valid integer')
            if choose == 1:
                decoy_ip = input('please enter the decoy IPs: ')
                scan_argus = argument_creator()
                ns = nmap.PortScanner()
                print('Please enter port range: ', end='')
                ports = input()
                args = scan_argus + ' ' + '-D' + ' ' + decoy_ip
                ns.scan(ip, ports, args)
                print(ns.scanstats())
                print(ns.csv())
                c = True
            elif choose == 2:
                decoy_ip = 'RND:'
                numdec = input('Please enter the number of decoys: ')
                scan_argus = argument_creator()
                ns = nmap.PortScanner()
                print('Please enter port range: ', end='')
                ports = input()
                args = scan_argus + ' ' + '-D' + ' ' + decoy_ip + numdec
                ns.scan(ip, ports, args)
                print(ns.scanstats())
                print(ns.csv())
                c = True
            else:
                print('YOU MUST ENTER EITHER ONE OR TWO')
                c = False

class fragmentation():
    arg = '-f --send-eth'
    def fragmentation():
        ip = input("please enter the host IP address: ")
        scan_argus = argument_creator()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        args = scan_argus + ' ' + '-f --send-eth'
        ns.scan(ip, ports, args)
        print(ns.scanstats())
        print(ns.csv())

class MTU():
    def MTU():
        ip = input("please enter the host IP address: ")
        scan_argus = argument_creator()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        unit = input('Please enter the unit in multiple of 8: ')
        args = scan_argus + ' ' + '--mtu ' + unit + ' --send-eth'
        ns.scan(ip, ports, args)
        print(ns.scanstats())
        print(ns.csv())

class timing_performance():
    def timing_performance():
        ip = input('Please enter the host IP address: ')
        scan_argus = argument_creator()
        timing = ''
        c_T = input('Do you want to use a timing template? [y/n]: ')
        if c_T in ('y', 'Y'):
            temp = input('Please specify a template from T0, T1, T2, T3, T4, T5: ')
            if c_T != '':
                timing = timing + temp
        c_P = input("Do you want to use parallelism?[y/n]: ")
        if c_P in ('y', 'Y'):
            minparallelism = input('Please enter the minimum parallelism: ')
            maxparallelism = input('Please enter the maximum parallelism: ')
            if minparallelism != '':
                timing = timing + ' --min-parallelism ' + minparallelism
            if maxparallelism != '':
                timing = timing + ' --max-parallelism ' + maxparallelism
        c_HG = input("Do you want to use host group size?[y/n]: ")
        if c_HG in ('y', 'Y'):
            minhostgroup = input('Please enter the minimum host group size: ')
            maxhostgroup = input('Please enter the maximum host group size: ')
            if minhostgroup != '':
                timing = timing + ' --min-hostgroup ' + minhostgroup
            if maxhostgroup != '':
                timing = timing + ' --max-hostgroup ' + maxparallelism
        c_HT = input('Do you want to use host timeout? [y/n]: ')
        if c_HT in ('y', 'Y'):
            hosttimeout = input('Please enter the host time in seconds ex-10s: ')
            if hosttimeout != '':
                timing = timing + ' --host-timeout ' + hosttimeout
        c_S = input('Do you want to use scan delay? [y/n]: ')
        if c_S in ('y', 'Y'):
            delay = input('Please enter the scan delay in seconds ex- 5s: ')
            if delay != '':
                timing = timing + ' --scan-delay ' + delay
        c_P = input('Do you want to use packet rate? [y/n]: ')
        if c_P in ('y', 'Y'):
            minrate = input('Please enter the minimum packet rate: ')
            maxrate = input('Please enter the maximum packet rate: ')
            if minrate != '':
                timing = timing + ' --min-rate ' + minrate
            if maxrate != '':
                timing = timing + ' --max-rate ' + maxrate
        print('timing: ', timing)
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        args = scan_argus + ' ' + timing
        ns.scan(ip, ports, args)
        print(ns.scanstats())
        print(ns.csv())
class custom_scan():

    def custom_scan(): ## enter own arguments##
        print('Please enter host ip address: ', end='')
        ip = input()
        ns = nmap.PortScanner()
        print('Please enter port range: ', end='')
        ports = input()
        print('Please enter arguments : ', end='')
        args = input()
        save = input('Would you like to save the file:[y/n] ')
        if save in ('y','Y'):
            name = input('Please enter the file name to save your scan: ')
            args = args + '  '+ '-oN' + ' ' + name
        ns.scan(ip, ports, args)
        print(ns.scanstats())
        print(ns.csv())

    def runme():
        arg = input('Please enter the arguments: ')
        return arg

def map_choice_start():
    try:
        strg = ''' Please enter the corresponding number for the scan that you wish to perform:
                          1. ping_sweep   
                          2. no_host_discovery
                          3. full_scan
                          4. syn_scan
                          5. service_version_detection
                          6. default_nse_scripts
                          7. tcp_connect (scan for all tcp services)
                          8. udp_connect (scan for all udp services)
                          9. check_firewall
                          10. fin_scan
                          11. null_scan
                          12. xmas_scan
                          13. firewall_eavsion_decoy
                          14. firewall_eavsion_fragmentation
                          15. firewall_eavsion_MTU
                          16. timing_performance_scan
                          17. custom_scan (enter the nmap arguments yourself)
                    ** Nmap Scriptng Engine to be added soon(use custom_scan if you know the commands)**
                '''
        global choice
        choice = int(input(strg,))
    except Exception as e:
        print('please enter a valid integer from the given options options')


def do_choice():
    global x
    x = 0
    map_choice_start()
    if choice == 1:
        ping_sweep.ping_sweep()
        x=1
    elif choice == 2:
        no_host_discovery.no_host_discovery()
        x=2
    elif choice == 3 :
        full_scan_noised.full_scan_noised()
        x=3
    elif choice == 4 :
        syn_scan.syn_scan()
        x=4
    elif choice == 5 :
        service_version_detection.service_version_detection()
        x=5
    elif choice == 6 :
        default_nse_scripts.default_nse_scripts()
        x=6
    elif choice==7:
        tcp_connect.tcp_connect()
        x=7
    elif choice == 8:
        udp_connect.udp_connect()
        x=8
    elif choice==9:
        check_firewall.check_firewall()
        x=9
    elif choice==10:
        fin_scan.fin_scan()
        x=10
    elif choice==11:
        null_scan.null_scan()
        x=11
    elif choice==12:
        xmas_scan.xmas_scan()
        x=12
    elif choice==13:
        decoy.decoy()
        x=13
    elif choice==14:
        fragmentation.fragmentation()
        x=14
    elif choice == 15:
        MTU.MTU()
        x=15
    elif choice==16:
        timing_performance.timing_performance()
        x=16
    elif choice==17:
        custom_scan.custom_scan()
        x=17
    else:
            print('Please enter a valid integer from the eight given options')
            x=0

def map_choice_start2():
    try:
        strg = ''' Please enter the space separated numbers for the scans that you wish to perform:
                          1. ping_sweep   
                          2. no_host_discovery
                          3. full_scan
                          4. syn_scan
                          5. service_version_detection
                          6. default_nse_scripts
                          7. tcp_connect (scan for all tcp services)
                          8. udp_connect (scan for all udp services)
                          9. check_firewall
                          10. fin_scan
                          11. null_scan
                          12. xmas_scan
                          13. custom_input
                '''
        global choice2
        print(strg)
        choice2 = list(map(int,input().split(',')))

    except Exception as e2:
        print('please enter a valid integer from the given options options')

def do_choice2():
    global x2
    argu = ''
    x2=0
    if i == 1:
        argu = argu + ping_sweep.arg
        x2=1
    elif i == 2:
        argu = argu + no_host_discovery.arg
        x2=2
    elif i == 3 :
        argu = argu + full_scan_noised.arg
        x2=3
    elif i == 4 :
        argu = argu + syn_scan.arg
        x2=4
    elif i == 5 :
        argu = argu + service_version_detection.arg
        x2=5
    elif i == 6 :
        argu = argu + default_nse_scripts.arg
        x2 = 6
    elif i==7:
        argu = argu + tcp_connect.arg
        x2=7
    elif i == 8:
        argu = argu + udp_connect.arg
        x2=8
    elif i==9:
        argu = argu + check_firewall.arg
        x2=9
    elif i==10:
        argu = argu + fin_scan.arg
        x2=10
    elif i==11:
        argu = argu + null_scan.arg
        x2=11
    elif i==12:
        argu = argu + xmas_scan.arg
        x2=12
    elif i==13:
        argu = argu + custom_scan.runme()
        x2=13
    else:
        print('Please enter a valid integer from the nine given options')
        x2=0
    return argu

def argument_creator():
    global ar
    ar = ''
    map_choice_start2()
    global i
    for i in choice2:
        ar = ar + ' ' + do_choice2()
    save_status = input('Do you want to save your scan in a file:[y/n] ')
    if save_status in ('y','Y'):
        ar = ar + ' ' + '-oN'
        name = input('Enter the file name for saving: ')
        ar = ar +' '+name
    print(ar)
    return ar
do_choice()
while x == 0:
    do_choice()